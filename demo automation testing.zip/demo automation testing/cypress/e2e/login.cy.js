/// <reference types="cypress" />

describe('My First Test Suite', () => {
  it('My First Test Case', () => {
    cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

    cy.get('div')
    .children('button')
    .eq(2)
    .should('be.visible')
    .click()
    
  })

 
})