describe('test 6', () => {
    it('Switch Window test', () => {

        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

        cy.get('#openwindow').invoke('removeAttr', 'onclick')
        .click()

           //.should('have.class', 'btn-style class1')
           
        

       
    })
})