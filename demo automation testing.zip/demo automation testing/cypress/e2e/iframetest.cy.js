///<reference types="Cypress" />
///<reference types="cypress-iframe" />
import 'cypress-iframe'

describe('Frame Tests', ()=>{
    it('iFrame Demo Test', () => {
     cy.visit('https://rahulshettyacademy.com/AutomationPractice/')   
     cy.frameLoaded('#courses-iframe')

     cy.iframe().find("a[href*='mentorship']").eq(0).click()


    })
})