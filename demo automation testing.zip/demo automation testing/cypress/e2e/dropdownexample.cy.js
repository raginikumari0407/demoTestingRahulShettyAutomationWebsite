describe('test 4', () => {
    it('Dropdown test', () => {

        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

        cy.get('#dropdown-class-example')
        .should('contain','Select')
        .and('be.visible')
        .select('option1')
        .should('have.value','option1')

        .should('contain','Option2')
        .select('Option2')
        .should('have.value','option2')

        .should('contain','Option3')
        .select('option3')
        .should('have.value','option3')
    })
})