it('Radio Button Example test', () => {

    cy.visit('https://rahulshettyacademy.com/AutomationPractice/')
    cy.get("#radio-btn-example")
    const name = 'Radio Button Example'
    expect(name).to.be.equal('Radio Button Example')


    cy.get('[type="radio"].radioButton')
    .first()
    .should('be.visible')
    .should('have.value','radio1')
    .check()

    cy.get('[type="radio"].radioButton')
    .check('radio2')
    .should('be.checked')

    cy.get('[value="radio3"]')
    .should('be.visible')
    .check().should('be.checked')
    

  })