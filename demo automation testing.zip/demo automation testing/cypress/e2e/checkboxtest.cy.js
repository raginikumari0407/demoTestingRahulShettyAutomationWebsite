describe('test 5', () => {
    it('Checkbox test', () => {

        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

       cy.get('#checkBoxOption1').check().should('be.checked').and('have.value', 'option1')
       cy.get('#checkBoxOption1').uncheck().should('not.be.checked')


       //for checking multiple checkboxes at a time

       cy.get('input[type="checkbox"]').check(['option2','option3'])
        
        //uncheck the checkboxes
        cy.get('[type="checkbox"]').uncheck(['option2'])

    })
})