/// <reference types="cypress" />

describe('test 9', () => {
    it('Mouse Hover test', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

        cy.get('div.mouse-hover-content').invoke('show')
        cy.contains('Top').click()
        cy.url().should('include', 'top')

        cy.contains('Reload').click()
    
        
    })
})