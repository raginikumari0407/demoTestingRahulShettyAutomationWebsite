describe('test8', ()=> {
    it('Element Displayed Example Test', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

        cy.get('#displayed-text').should('be.visible')

        cy.get('#hide-textbox')
        .should('have.value','Hide')
        .click()
        cy.get('#displayed-text').should('not.be.visible')

        cy.get('#show-textbox')
        .should('have.value','Show')
        .click()

        cy.get('#displayed-text').should('be.visible')
    })
})