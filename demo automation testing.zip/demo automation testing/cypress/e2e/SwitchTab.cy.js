describe('test 10', () => {
    it('Switch Tab Example test', () => {

        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')

        cy.get('#opentab').invoke('removeAttr', 'target')
        .click()

        cy.url().should('include', 'rahulshettyacademy')

        cy.go(-1)
       
    })
})